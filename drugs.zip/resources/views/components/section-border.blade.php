<div class="d-none d-sm-block">
    <div class="py-4">
        <hr class="border-top border-gray-200">
    </div>
</div>