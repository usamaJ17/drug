<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['submit']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['submit']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?php echo e($title); ?></h5>
    <p class="card-subtitle"><?php echo e($description); ?></p>
  </div>
  <div class="card-body">
    <form wire:submit.prevent="<?php echo e($submit); ?>">
      <?php echo e($form); ?>

      <!--[if BLOCK]><![endif]--><?php if(isset($actions)): ?>
        <div class="d-flex justify-content-end">
          <?php echo e($actions); ?>

        </div>
      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </form>
  </div>
</div>
<?php /**PATH /home/usama/php/drug/resources/views/components/form-section.blade.php ENDPATH**/ ?>