<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-danger text-white'])); ?>>
  <?php echo e($slot); ?>

</button>
<?php /**PATH /home/usama/php/drug/resources/views/components/danger-button.blade.php ENDPATH**/ ?>