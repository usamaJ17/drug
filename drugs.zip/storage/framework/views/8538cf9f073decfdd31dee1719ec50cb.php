<?php $__env->startSection('title', ' Vertical Layouts - Forms'); ?>

<!-- Vendor Styles -->
<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
  'resources/assets/vendor/libs/select2/select2.scss',
]); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')([
  'resources/assets/vendor/libs/cleavejs/cleave.js',
  'resources/assets/vendor/libs/cleavejs/cleave-phone.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js',
  'resources/assets/vendor/libs/select2/select2.js'
]); ?>
<?php $__env->stopSection(); ?>

<!-- Page Scripts -->
<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form-layouts.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Basic Layout -->
<div class="row">
  <div class="col-xl mb-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Search Drugs</h5>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('drug-search')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="mb-6">
            <label class="form-label" for="basic-default-fullname">NDC / Name</label>
            <input type="text" class="form-control" id="basic-default-fullname" name="ndc" placeholder="Enter Name or NDC" />
          </div>
          <div class="mb-6">
            <label for="insurance" class="form-label">Insurance</label>
            <select id="insurance" class="select2 form-select form-select-lg" name="insurance" data-allow-clear="true">
                <option >Select Insurance</option>
                <?php $__currentLoopData = $uniqueInsurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="mb-6">
            <label class="form-label" for="basic-default-group">Group</label>
            <input type="text" class="form-control" id="basic-default-group" name="customer_group" placeholder="Enter Group Name" />
          </div>
          <div class="mb-6">
            <label class="form-label" for="basic-default-bin">Bin</label>
            <input type="text" id="basic-default-bin" class="form-control" name="bin" placeholder="Enter Bin" />
          </div>
          <button type="submit" class="btn btn-primary">Search</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usama/php/drug/resources/views/main/search.blade.php ENDPATH**/ ?>