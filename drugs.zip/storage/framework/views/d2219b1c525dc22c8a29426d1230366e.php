<div class="card">
  <div class="card-header">
    <h5 class="card-title"><?php echo e($title); ?></h5>
    <p class="card-subtitle"><?php echo e($description); ?></p>
  </div>
  <div class="card-body"><?php echo e($content); ?></div>
</div><?php /**PATH /home/usama/php/drug/resources/views/components/action-section.blade.php ENDPATH**/ ?>