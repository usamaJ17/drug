<?php $__env->startSection('title', 'User List - Pages'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/@form-validation/form-validation.scss', 'resources/assets/vendor/libs/animate-css/animate.scss', 'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/moment/moment.js', 'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js', 'resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/@form-validation/popular.js', 'resources/assets/vendor/libs/@form-validation/bootstrap5.js', 'resources/assets/vendor/libs/@form-validation/auto-focus.js', 'resources/assets/vendor/libs/cleavejs/cleave.js', 'resources/assets/vendor/libs/cleavejs/cleave-phone.js', 'resources/assets/vendor/libs/sweetalert2/sweetalert2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/assets/js/app-drugs-list.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-datatable table-responsive">
            <table class="datatables-users table">
                <thead class="border-top">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Drug Name
                        </th>
                        <th scope="col" class="px-6 py-3">
                            NDC
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Quantity
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Insurance
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Bin
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Customer Group Number
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Primary Ins Pay
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Net Profit
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Profit Per Pill
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr
                            class="bg-gray-800 border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-600 dark:hover:bg-gray-600">
                            <th scope="row"
                                class="px-6 py-4 font-medium text-white-900 whitespace-nowrap dark:text-white">
                                <?php echo e($item->name); ?>

                            </th>
                            <td class="px-6 py-4">
                                <?php echo e($item->ndc); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($item->qty); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($item->insurance); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($item->bin); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($item->customer_group); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($item->primary_ins_pay); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($item->net_profit); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e(number_format($item->net_profit / $item->qty, 2)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usama/php/drug/resources/views/main/drugs-list.blade.php ENDPATH**/ ?>