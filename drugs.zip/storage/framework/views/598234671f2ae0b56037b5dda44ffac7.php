<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary'])); ?>>
  <?php echo e($slot); ?>

</button>
<?php /**PATH /home/usama/php/drug/resources/views/components/button.blade.php ENDPATH**/ ?>